"""Owner B (Khoa), reviewer C (Khải): assemble data, model, optimizer and the shared engine."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from secrets import token_hex
from typing import Any, Literal, Optional
import numpy as np
import random
import time
import torch
from tqdm import tqdm

from dlbench.a1.contracts import EpochMetrics, EvaluationResult, FitResult
from dlbench.a1.data.loaders import build_dataloaders
from dlbench.a1.engine import train_one_epoch, evaluate_epoch
from dlbench.a1.models.registry import build_model
from dlbench.common.artifacts import (
    checkpoint_provenance,
    create_run_dir,
    save_run_metadata,
    append_history,
    save_metrics,
    compute_data_provenance,
    HISTORY_COLUMNS,
    _validate_history_row,
)
from dlbench.common.config import validate_config
from dlbench.a1.checkpoint import save_checkpoint, is_better, load_checkpoint
from dlbench.common.reproducibility import seed_everything, capture_rng_state, restore_rng_state


def _truncate_history(run_dir: Path, target_epoch: int) -> None:
    import csv
    import io
    import os
    import tempfile
    from uuid import uuid4
    
    history_file = run_dir / "history.csv"
    
    best_pt = run_dir / "best.pt"
    if best_pt.exists():
        import torch
        best_payload = torch.load(best_pt, map_location="cpu", weights_only=False)
        best_epoch = best_payload.get("epoch", -1)
        if best_epoch > target_epoch:
            raise ValueError(f"Cannot resume from epoch {target_epoch} which is older than best.pt (epoch {best_epoch})")

    if not history_file.exists():
        if target_epoch >= 0:
            raise ValueError(f"History file missing but trying to resume from epoch {target_epoch}")
        return

    content = history_file.read_text(encoding="utf-8")
    if not content.endswith("\n"):
        raise ValueError("History is empty or has an incomplete final line")
        
    reader = csv.DictReader(io.StringIO(content, newline=""))
    if reader.fieldnames != list(HISTORY_COLUMNS):
        raise ValueError("Existing history header does not match HISTORY_COLUMNS")
        
    valid_rows = []
    last_epoch = -1
    for i, saved in enumerate(reader):
        try:
            parsed = {key: int(saved[key]) if key == "epoch" else float(saved[key])
                      for key in HISTORY_COLUMNS}
            if set(saved) != set(HISTORY_COLUMNS):
                raise ValueError("Unexpected CSV fields")
            _validate_history_row(parsed)
        except (TypeError, ValueError, KeyError) as exc:
            raise ValueError(f"Existing history contains an invalid row at line {i+2}") from exc
            
        if parsed["epoch"] != last_epoch + 1:
            raise ValueError("History epochs must be contiguous starting from 0")
        last_epoch = parsed["epoch"]
        if parsed["epoch"] <= target_epoch:
            valid_rows.append(saved)
            
    if last_epoch < target_epoch:
        raise ValueError(f"History missing rows up to epoch {target_epoch}")
        
    if last_epoch == target_epoch:
        return
        
    old_bytes = history_file.read_bytes()
    backups = run_dir / "backups"
    backups.mkdir(exist_ok=True)
    backup_path = backups / f"history-{uuid4().hex}.csv"
    
    try:
        with backup_path.open("xb") as file:
            file.write(old_bytes)
            file.flush()
            os.fsync(file.fileno())
    except Exception as exc:
        raise RuntimeError("Failed to backup history file") from exc
        
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="", dir=run_dir,
            prefix=".history.", suffix=".tmp", delete=False,
        ) as file:
            temporary_path = Path(file.name)
            writer = csv.DictWriter(file, fieldnames=HISTORY_COLUMNS)
            writer.writeheader()
            for row in valid_rows:
                writer.writerow(row)
            file.flush()
            os.fsync(file.fileno())
            
        os.replace(temporary_path, history_file)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)



def generate_run_id(config: Mapping[str, Any], *, smoke: bool = False) -> str:
    """Create an A1 run ID with UTC time and a short collision-resistant suffix."""
    model_name = config.get("model", {}).get("name", "model")
    smoke_status = "smoke" if smoke else "main"
    run_seed = config["run"]["seed"]
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    suffix = token_hex(3)
    return f"a1_{model_name}_{smoke_status}_seed{run_seed}_{timestamp}_{suffix}"


def get_device() -> torch.device:
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif torch.backends.mps.is_available():  # Apple Silicon (M1/M2/M3/M4)
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    return device


def get_optimizer(model: torch.nn.Module, training_config: Mapping[str, Any]) -> torch.optim.Optimizer:
    optimizer_name = training_config.get("optimizer", "adam").lower()
    lr = float(training_config.get("learning_rate", 0.001))
    weight_decay = float(training_config.get("weight_decay", 0.0))

    supported_optimizers = ("adam", "adamw", "sgd", "rmsprop", "adagrad", "adadelta", "adamax", "nadam")

    if optimizer_name == "adam":
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    elif optimizer_name == "adamw":
        optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    elif optimizer_name == "sgd":
        momentum = float(training_config.get("momentum", 0.9))
        optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
    elif optimizer_name == "rmsprop":
        momentum = float(training_config.get("momentum", 0.9))
        optimizer = torch.optim.RMSprop(
            model.parameters(),
            lr=lr,
            momentum=momentum,
            weight_decay=weight_decay,
            alpha=float(training_config.get("alpha", 0.99)),
            eps=float(training_config.get("eps", 1e-08)),
            centered=bool(training_config.get("centered", False)),
        )
    elif optimizer_name == "adagrad":
        optimizer = torch.optim.Adagrad(
            model.parameters(),
            lr=lr,
            lr_decay=float(training_config.get("lr_decay", 0.0)),
            weight_decay=weight_decay,
            eps=float(training_config.get("eps", 1e-10)),
        )
    elif optimizer_name == "adadelta":
        optimizer = torch.optim.Adadelta(
            model.parameters(),
            lr=lr,
            rho=float(training_config.get("rho", 0.9)),
            eps=float(training_config.get("eps", 1e-06)),
            weight_decay=weight_decay,
        )
    elif optimizer_name == "adamax":
        optimizer = torch.optim.Adamax(
            model.parameters(),
            lr=lr,
            betas=(float(training_config.get("beta1", 0.9)), float(training_config.get("beta2", 0.999))),
            eps=float(training_config.get("eps", 1e-08)),
            weight_decay=weight_decay,
        )
    elif optimizer_name == "nadam":
        optimizer = torch.optim.NAdam(
            model.parameters(),
            lr=lr,
            betas=(float(training_config.get("beta1", 0.9)), float(training_config.get("beta2", 0.999))),
            eps=float(training_config.get("eps", 1e-08)),
            weight_decay=weight_decay,
        )
    else:
        raise ValueError(
            f"Unsupported optimizer: {optimizer_name}. Supported optimizers are {', '.join(supported_optimizers)}."
        )
    return optimizer


def resolve_device(config: Mapping[str, Any] | None = None) -> torch.device:
    """Use run.device when supplied; otherwise auto-detect hardware."""
    run_config = config.get("run", {}) if config is not None else {}
    requested_device = str(run_config.get("device", "auto")).strip().lower()

    if requested_device in ("", "auto"):
        return get_device()

    try:
        return torch.device(requested_device)
    except Exception as exc:
        raise ValueError(f"Unsupported run.device: {requested_device}") from exc


def _resolve_smoke_config(config: Mapping[str, Any]) -> dict[str, Any]:
    """Make smoke runs use explicit, small, positive budgets."""
    resolved = deepcopy(dict(config))
    budget = resolved.setdefault("budget", {})
    training = resolved.setdefault("training", {})

    try:
        max_epochs = int(budget.get("max_epochs", 0))
    except (TypeError, ValueError):
        max_epochs = 0

    if max_epochs <= 0:
        budget["max_epochs"] = 10
    else:
        budget["max_epochs"] = min(max_epochs, 10)

    try:
        batch_size = int(training.get("batch_size", 0))
    except (TypeError, ValueError):
        batch_size = 0

    if batch_size <= 0:
        training["batch_size"] = 16
    else:
        training["batch_size"] = min(batch_size, 16)

    try:
        save_frequency = int(training.get("save_frequency", 1))
    except (TypeError, ValueError):
        save_frequency = 1

    training["save_frequency"] = max(save_frequency, 1)
    return resolved


def get_scheduler(optimizer: torch.optim.Optimizer, training_config: Mapping[str, Any]) -> Any:
    scheduler_config = training_config.get("scheduler")
    if not scheduler_config:
        return None
    
    name = scheduler_config.get("name", "").lower()
    params = scheduler_config.get("parameters", {})
    
    if name == "step":
        return torch.optim.lr_scheduler.StepLR(
            optimizer, 
            step_size=params.get("step_size", 10), 
            gamma=params.get("gamma", 0.1)
        )
    elif name == "exponential":
        return torch.optim.lr_scheduler.ExponentialLR(
            optimizer, 
            gamma=params.get("gamma", 0.9)
        )
    elif name == "cosine":
        return torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, 
            T_max=params.get("T_max", 50), 
            eta_min=params.get("eta_min", 0.0)
        )
    elif name == "reduce_on_plateau":
        return torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, 
            mode=params.get("mode", "min"), 
            factor=params.get("factor", 0.1), 
            patience=params.get("patience", 10),
            min_lr=params.get("min_lr", 0.0)
        )
    elif name == "polynomial":
        return torch.optim.lr_scheduler.PolynomialLR(
            optimizer, 
            total_iters=params.get("total_iters", 100), 
            power=params.get("power", 1.0)
        )
    else:
        raise ValueError(f"Unsupported scheduler: {name}")


def fit(config: Mapping[str, Any], *, smoke: bool = False, resume_from: Path | None = None) -> FitResult:
    """Seed -> loaders -> model -> optimizer -> train/val epochs -> artifacts.

    Main runs require strict config validation AND valid existing split/stats.
    Smoke runs: explicitly limited training/validation data, positive small
    epoch/batch budget, separate smoke directory, no official-test evaluation.
    Call engine.py, checkpoint.py and common/artifacts.py; do not duplicate them.
    Save resolved config and actual epoch/time budget. Never overwrite a run.
    """
    resolved_config = _resolve_smoke_config(config) if smoke else deepcopy(dict(config))
    resolved_config["run"]["mode"] = "smoke" if smoke else "main"

    validate_config(resolved_config, strict=not smoke)
    run_config = resolved_config["run"]
    # Prepare deterministic behavior
    run_seed = run_config["seed"]
    seed_everything(run_seed)

    # Resume or create run
    if resume_from is None:
        output_root = Path(run_config.get('output_root', 'runs/a1'))
        run_id = generate_run_id(resolved_config, smoke=smoke)
        run_dir = create_run_dir(output_root, run_id)
        metadata = save_run_metadata(run_dir, resolved_config)
        metadata_provenance = checkpoint_provenance(metadata)
        start_epoch = 0
    else:
        payload = load_checkpoint(resume_from, resume=True)
        run_dir = resume_from.parent

        current_provenance = compute_data_provenance(resolved_config)
        if payload["split_hash"] != current_provenance["split_hash"]:
            raise ValueError("Checkpoint split does not match the supplied configuration.")
        if payload["statistics_hash"] != current_provenance["statistics_hash"]:
            raise ValueError("Checkpoint preprocessing does not match the supplied configuration.")

        for section in ("protocol", "model", "preprocessing", "training"):
            if payload["config"].get(section) != resolved_config.get(section):
                raise ValueError(f"Configuration mismatch in section: {section}")
                
        old_run = payload["config"].get("run", {})
        new_run = resolved_config.get("run", {})
        if old_run.get("seed") != new_run.get("seed") or old_run.get("mode") != new_run.get("mode"):
            raise ValueError("Configuration mismatch in run (seed or mode)")

        metadata_provenance = {
            "schema_version": payload["schema_version"],
            "split_hash": payload["split_hash"],
            "statistics_hash": payload["statistics_hash"],
            "git_revision": payload["git_revision"],
        }
        start_epoch = payload["epoch"] + 1

    # Use device from config when provided; otherwise auto-detect.
    device = resolve_device(resolved_config)

    # Build data loaders
    dataloaders = build_dataloaders(resolved_config, smoke=smoke)

    # Build model
    model_config = resolved_config['model']
    model = build_model(model_config)
    model.to(device)

    # Setup optimizer
    training_config = resolved_config.get("training", {})
    optimizer = get_optimizer(model, training_config)
    scheduler = get_scheduler(optimizer, training_config)

    if resume_from is not None:
        model.load_state_dict(payload["model_state_dict"])
        optimizer.load_state_dict(payload["optimizer_state_dict"])
        if scheduler and payload.get("scheduler_state_dict"):
            scheduler.load_state_dict(payload["scheduler_state_dict"])
        restore_rng_state(payload["rng_state"])
        if payload.get("dataloader_generator_state") is not None and hasattr(dataloaders.train, "generator") and dataloaders.train.generator is not None:
            dataloaders.train.generator.set_state(payload["dataloader_generator_state"])
        _truncate_history(run_dir, payload["epoch"])

    # Setup loss function
    criterion = torch.nn.CrossEntropyLoss()

    # Get training parameters
    max_epochs = int(resolved_config["budget"]["max_epochs"])
    

    # Track best model
    early_stopping_patience = int(training_config.get("early_stopping_patience", 0))
    min_delta = float(training_config.get("min_delta", 0.0))
    save_frequency = int(training_config.get("save_frequency", 1))
    early_stopping_monitor = training_config.get("early_stopping_monitor", "macro_f1")
    if early_stopping_patience < 0:
        raise ValueError("early_stopping_patience must be nonnegative")
    if min_delta < 0.0:
        raise ValueError("min_delta must be nonnegative")
    if save_frequency <= 0:
        raise ValueError("save_frequency must be positive")
    if early_stopping_monitor not in ("macro_f1", "loss"):
        raise ValueError("early_stopping_monitor must be 'macro_f1' or 'loss'")

    # Track best model — on resume, load best.pt for the historical best
    # threshold so we never overwrite it with a worse model.
    best_checkpoint_path = run_dir / "best.pt"
    if resume_from is not None and best_checkpoint_path.is_file():
        best_payload = load_checkpoint(best_checkpoint_path)
        best_val_metrics = EpochMetrics(**best_payload["val_metrics"])
        best_selection_metrics = {
            "epoch": best_payload["epoch"],
            "val_macro_f1": best_payload["val_metrics"]["macro_f1"],
            "val_loss": best_payload["val_metrics"]["loss"],
        }
        best_epoch = best_payload["epoch"]
    elif resume_from is not None:
        # No best.pt yet (e.g. interrupted before first epoch finished);
        # fall back to last epoch's metrics as the initial threshold.
        best_val_metrics = None
        best_selection_metrics = {
            "epoch": payload["epoch"],
            "val_macro_f1": payload["val_metrics"]["macro_f1"],
            "val_loss": payload["val_metrics"]["loss"],
        }
        best_epoch = -1
    else:
        best_val_metrics = None
        best_selection_metrics = None
        best_epoch = -1

    # Early stopping counters — these can't be derived from best.pt,
    # so they are persisted in last.pt.
    best_monitor_value = payload.get("best_monitor_value") if resume_from is not None else None
    epochs_without_improvement = payload.get("epochs_without_improvement", 0) if resume_from is not None else 0

    # Training loop
    pbar = tqdm(range(start_epoch, max_epochs))
    
    for epoch in pbar:
        start_time = time.time()

        # Train
        train_metrics = train_one_epoch(
            model=model,
            loader=dataloaders.train,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
        )

        # Validate
        val_metrics: EvaluationResult = evaluate_epoch(
            model=model,
            loader=dataloaders.validation,
            criterion=criterion,
            device=device,
        )

        epoch_time = time.time() - start_time

        # Prepare history row
        history_row = {
            "epoch": epoch,
            "train_loss": train_metrics.loss,
            "val_loss": val_metrics.metrics.loss,
            "train_accuracy": train_metrics.accuracy,
            "val_accuracy": val_metrics.metrics.accuracy,
            "train_macro_f1": train_metrics.macro_f1,
            "val_macro_f1": val_metrics.metrics.macro_f1,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "epoch_seconds": epoch_time,
        }

        # Append to history
        append_history(run_dir, history_row)

        if scheduler is not None:
            if isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                mode = training_config.get("scheduler", {}).get("parameters", {}).get("mode", "min")
                metric = val_metrics.metrics.macro_f1 if mode == "max" else val_metrics.metrics.loss
                scheduler.step(metric)
            else:
                scheduler.step()

        # Check if this is the best model so far
        checkpoint_payload = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict() if scheduler else None,
            "rng_state": capture_rng_state(),
            "dataloader_generator_state": dataloaders.train.generator.get_state() if hasattr(dataloaders.train, "generator") and dataloaders.train.generator is not None else None,
            "config": dict(resolved_config),
            "val_metrics": asdict(val_metrics.metrics),
            "run_seed": run_seed,
            "schema_version": 1,
            **metadata_provenance,
        }

        selection_metrics = {
            "val_macro_f1": val_metrics.metrics.macro_f1,
            "val_loss": val_metrics.metrics.loss,
            "epoch": epoch,
        }

        # Save resumable state at the configured frequency, at the final epoch,
        # and when early stopping cuts the run short.
        last_checkpoint_path = run_dir / "last.pt"
        should_save_last = (epoch + 1) % save_frequency == 0 or epoch == max_epochs - 1

        # Update best model if needed
        if is_better(selection_metrics, best_selection_metrics):
            best_val_metrics = val_metrics.metrics
            best_selection_metrics = selection_metrics
            best_epoch = epoch
            # Save best checkpoint
            save_checkpoint(best_checkpoint_path, checkpoint_payload, resume=False)

        if early_stopping_monitor == "macro_f1":
            monitor_value = val_metrics.metrics.macro_f1
            improved = best_monitor_value is None or monitor_value > best_monitor_value + min_delta
        else:
            monitor_value = val_metrics.metrics.loss
            improved = best_monitor_value is None or monitor_value < best_monitor_value - min_delta

        if improved:
            best_monitor_value = monitor_value
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
            
        pbar.set_postfix({
            "val_f1": f"{val_metrics.metrics.macro_f1:.4f}",
            "val_loss": f"{val_metrics.metrics.loss:.4f}",
            "train_loss": f"{train_metrics.loss:.4f}",
            "lr": f"{optimizer.param_groups[0]['lr']:.2e}",
            "wait": f"{epochs_without_improvement}/{early_stopping_patience}"
        })

        def save_last():
            checkpoint_payload["best_monitor_value"] = best_monitor_value
            checkpoint_payload["epochs_without_improvement"] = epochs_without_improvement
            save_checkpoint(last_checkpoint_path, checkpoint_payload, resume=True)

        if early_stopping_patience > 0 and epochs_without_improvement >= early_stopping_patience:
            save_last()
            break

        if should_save_last:
            save_last()

    # Save final metrics
    final_metrics = {
        "eval_split": "validation",
        "val_loss": best_val_metrics.loss if best_val_metrics else 0.0,
        "val_accuracy": best_val_metrics.accuracy if best_val_metrics else 0.0,
        "val_macro_f1": best_val_metrics.macro_f1 if best_val_metrics else 0.0,
        "epoch": best_epoch,
        "timing_scope": "fit",
        "timing_units": "seconds",
    }
    save_metrics(run_dir, final_metrics, overwrite=resume_from is not None)

    # Return FitResult
    history_file = run_dir / "history.csv"

    return FitResult(
        run_dir=run_dir,
        best_checkpoint=best_checkpoint_path,
        history_file=history_file,
    )


def evaluate_checkpoint(config: Mapping[str, Any], checkpoint_path: Path, *,
                        split: Literal["validation", "test"] = "validation",
                        smoke: bool = False) -> EvaluationResult:
    """Reconstruct from saved config; verify split hash, normalization and class order.

    Refuse incompatible supplied config. Evaluate the requested split with
    engine.evaluate_epoch; preserve checkpoint provenance. Test use is explicit
    and only after all model-selection decisions are fixed.
    Load only trusted checkpoints using an appropriate safe loading policy.
    """
    if split not in ("validation", "test"):
        raise ValueError(f"Unrecognized evaluation split: {split}")
    
    if smoke and split == "test":
        raise ValueError("Smoke evaluation cannot use the official test split.")
    
    resolved_config = _resolve_smoke_config(config) if smoke else deepcopy(dict(config))
    validate_config(resolved_config, strict=not smoke)

    device = resolve_device(resolved_config)
    map_location = device
    
    payload = load_checkpoint(checkpoint_path, map_location=map_location, resume=False)
    
    for section in (
        "protocol",
        "data",
        "preprocessing",
        "evaluation",
        "checkpoint",
        "model",
    ):
        if payload["config"].get(section) != resolved_config.get(section):
            raise ValueError(f"Configuration mismatch in section: {section}")
    
    current_provenance = compute_data_provenance(resolved_config)

    if payload["split_hash"] != current_provenance["split_hash"]:
        raise ValueError("Checkpoint split does not match the supplied configuration.")

    if payload["statistics_hash"] != current_provenance["statistics_hash"]:
        raise ValueError("Checkpoint preprocessing does not match the supplied configuration.")
    
    model = build_model(resolved_config["model"])
    model.load_state_dict(payload["model_state_dict"])
    
    model.to(device)
    
    loaders = build_dataloaders(resolved_config, smoke=smoke)
    loader = loaders.validation if split == "validation" else loaders.test
    
    criterion = torch.nn.CrossEntropyLoss()
    result = evaluate_epoch(model, loader, criterion, device)
    
    return result