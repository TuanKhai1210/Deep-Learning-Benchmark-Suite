<div align="center">

# Deep Learning Benchmark Suite

**A reproducible PyTorch project for benchmarking neural architectures across image classification, specialized deep learning tasks, and multimodal learning.**

[![Project Status](https://img.shields.io/badge/status-active%20development-2563eb)](https://github.com/TuanKhai1210/Deep-Learning-Benchmark-Suite)
[![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-framework-EE4C2C?logo=pytorch&logoColor=white)](https://pytorch.org/)
[![Project Site](https://img.shields.io/badge/GitHub%20Pages-project%20site-222222?logo=github)](https://tuankhai1210.github.io/Deep-Learning-Benchmark-Suite/)

[Project website](https://tuankhai1210.github.io/Deep-Learning-Benchmark-Suite/) ·
[Assignment 1](docs/a1.md) ·
[A1 report](reports/a1/A1-report.pdf) ·
[A1 slides](reports/a1/A1-presentation.pdf) ·
[A1 presentation video](https://www.youtube.com/watch?v=cfNiu5XLi10) ·
[A1 checkpoints](checkpoints/a1/) ·
[Assignment 2 proposal](reports/a2/Tiki-taka_A2_TrashCan_Material_Proposal.pdf) ·
[A2 M2 draft report](reports/a2/Tiki-taka_A2_M2_Progress_2026-10-28.pdf) ·
[AI usage disclosure](AI_USAGE.md)

</div>

---

## Overview

Deep Learning Benchmark Suite is an evolving collection of controlled experiments designed to answer a practical question:

> How do different deep learning architectures behave when they are trained and evaluated under the same data split, metrics, and reproducibility protocol?

The project begins with image classification and progressively extends toward specialized and multimodal learning. It emphasizes reproducible engineering, fair model comparison, transparent experiment tracking, and evidence-based analysis rather than accuracy alone.

## Project modules

| Module | Focus | Dataset or task | Status |
|---|---|---|---|
| Assignment 1 | Architecture benchmarking and end-to-end training pipelines | Fashion-MNIST image classification | Complete; report, slides, video, and checkpoints published |
| Assignment 2 | Underwater semantic segmentation | TrashCan 1.0 Material | Initial code available; approval/pilot pending |
| Assignment 3 | Multimodal representation, fusion, and evaluation | Pending dataset proposal and approval | Planned |

Assignment 1 remains under development. Assignment 2 has an initial development pipeline; main A2 experiments require instructor approval and a pilot-confirmed protocol.

Configuration validation and the command-line interface are available. Data preparation, model training, evaluation, and analysis are under development; no benchmark results are reported yet. See the [implementation guide](IMPLEMENTATION_GUIDE.md) for file ownership and implementation order.

## Assignment 1: Architecture Benchmark

Assignment 1 compares five model families on the same Fashion-MNIST split and evaluation protocol:

1. Linear classifier
2. Multilayer Perceptron (MLP)
3. Custom Convolutional Neural Network (CNN)
4. LSTM or GRU sequence model
5. Transformer encoder

### Evaluation dimensions

- Accuracy and macro-F1
- Parameter count
- Training and inference time
- Training and validation curves
- Confusion matrix
- Correct, difficult, and incorrect prediction examples
- Representation and inductive-bias analysis

### Reproducibility goals

Every reported result should be traceable to:

- A versioned configuration
- A fixed dataset split and random seed
- An experiment log or identifier
- A selected checkpoint
- The hardware and dependency versions used
- A corresponding Git commit or release tag

The team uses **split seed 36** to create one saved data partition. Model training is repeated with **run seeds 69420, 67, and 69**, giving five model families × three run seeds = **15 main training runs**, excluding debugging and tuning. Final results will report mean and standard deviation across the three run seeds, without selecting the best test seed.

Other experimental choices are still under review in the [A1 experiment contract](docs/a1-experiment-contract.md), including normalization statistics, compute budget, augmentation, and the final timing procedure.

## Assignment 2: TrashCan-Material Semantic Segmentation

Initial code: [implementation and commands](docs/a2_initial_code.md) ·
[development notebook](notebooks/a2_initial_code.ipynb) · [draft configs](configs/a2/README.md).
Synthetic CPU checks and checkpoint-resume tests establish development contracts;
real-data integration, GPU pilot and main results remain pending.

The team proposes underwater marine-debris semantic segmentation using **TrashCan 1.0 Material**. The proposal retains all 16 foreground categories, adds background (17 output classes), and excludes ambiguous overlap and letterbox padding with ignore ID `255`.

- [A2 M2 draft report PDF](reports/a2/Tiki-taka_A2_M2_Progress_2026-10-28.pdf)
- [Dataset proposal PDF](reports/a2/Tiki-taka_A2_TrashCan_Material_Proposal.pdf)
- [Assignment 2 project page](https://tuankhai1210.github.io/Deep-Learning-Benchmark-Suite/a2.html)
- [Proposal and evidence notes](reports/a2/README.md)
- [Group working data and EDA evidence](https://drive.google.com/drive/folders/1VwT0UyleGYyF9yrCtXaOwZpnp-ZRrfGD)
- [U-Net experiment artifacts](https://drive.google.com/drive/folders/1Z1gciMrfAX3pDuHOgkMnsbUoFGTkqpex)
- [SegFormer experiment artifacts](https://drive.google.com/drive/folders/1dKtoohwxRteQADWZIaNkajRsN9K6D3gu)

Measured preliminary EDA contains **7,212 images**, **12,336 object annotations**, and **312 filename-derived video groups**. The original train/validation split shares **127 video groups**. The new seed-`36` split assigns whole videos: **5,057 / 1,077 / 1,078 images** in train/validation/test, with zero pairwise video-group overlap. Original-split findings remain evidence, not the training partition.

The planned comparison is a scratch U-Net versus a pretrained SegFormer-B0, with a controlled color-augmentation on/off experiment within SegFormer. Primary evaluation is foreground macro mIoU, supported by foreground Dice, trash-only mIoU and per-class scores. The initial run seed is `69420`; paired repetitions at `67` and `69` are optional, compute-dependent plans.

**Status:** Proposal published to this repository on 7 October 2026. Instructor approval, main training, model results and LMS submission are not asserted. Raw data and large checkpoints remain outside Git.

## Repository structure

```text
deep-learning-benchmark-suite/
├── README.md                  # Project overview and setup
├── IMPLEMENTATION_GUIDE.md     # File ownership and development order
├── CONTRIBUTING.md            # Branches, reviews, and verification
├── PROJECT_PLAN.md            # Milestones and team responsibilities
├── AI_USAGE.md                # Verifiable AI-assistance log
├── setup.py                   # Python package and dependency declarations
├── configs/
│   ├── a1/
│   │   ├── protocol.py        # Shared experiment policy
│   │   ├── models/            # One Python config per model family
│   │   └── splits/            # Versioned split indices and identity
│   ├── a2/
│   └── a3/
├── src/dlbench/
│   ├── common/                # Config, reproducibility, and artifacts
│   └── a1/
│       ├── data/              # Dataset, split, transforms, loaders, EDA
│       ├── models/            # Linear, MLP, CNN, RNN, Transformer
│       ├── contracts.py       # Shared batch/model/metric interfaces
│       ├── cli.py             # Command-line entry point
│       ├── engine.py          # Epoch-level training and evaluation
│       └── trainer.py         # Full-run orchestration
├── tests/                     # Configuration and implementation tests
├── environment/               # Dependency and hardware records
├── notebooks/                 # Exploratory analysis, not the main pipeline
├── docs/                      # GitHub Pages and experiment contract
│   └── assets/a1/             # Small reviewed tables and figures
├── reports/a1/                # A1 report and presentation outline
├── reports/a2/                # A2 proposal and measured EDA summaries
├── data/                      # Local datasets, excluded from Git
├── runs/                      # Local run artifacts, excluded from Git
└── checkpoints/               # Model weights, excluded from Git
```

Datasets, checkpoints, local experiment logs, and credentials are intentionally excluded from Git. Checkpoint download links or reconstruction instructions will be documented with each release.

## Getting started

Clone the repository:

```bash
git clone https://github.com/TuanKhai1210/deep-learning-benchmark-suite.git
cd deep-learning-benchmark-suite
```

Use Python **3.11 or newer**. Create an isolated environment, then install the local package. On Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe -m dlbench.a1.cli --help
.\.venv\Scripts\python.exe -m dlbench.a1.cli validate-config --config configs/a1/models/linear.py
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

This base installation supports development checks without installing the ML stack. After choosing a compatible PyTorch/torchvision build for the team's hardware, install the optional ML dependencies and record the resolved versions:

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[ml]"
```

Experiment configs are `.py` files containing a single literal `CONFIG = {...}` dictionary. The shared rules live in `configs/a1/protocol.py`; model-specific settings live in `configs/a1/models/`. The loader parses data without importing or executing the file. Comments/docstrings are allowed; imports, calls, variables and computations are not.

`validate-config` checks development settings. Add `--strict` only after the team has genuinely completed and approved the protocol; unresolved values should fail strict validation. Use `--seed 69420`, `--seed 67`, or `--seed 69` to select a run seed in memory; it does not change the config file or the split created with seed `36`. Other run seeds are rejected.

The `prepare`, `train`, `evaluate`, and `analyze` commands define the intended workflow but currently stop at unimplemented ML functions. They are not evidence of a completed training pipeline. ML-dependent tests remain pending until their implementations and dependencies are ready.

Follow progress on the [Assignment 1 project page](docs/a1.md).

## Development workflow

The team uses short-lived feature branches and pull requests:

```text
feat/a1-data-eda
feat/a1-training-pipeline
feat/a1-models
docs/a1-results
```

Contributors should:

1. Branch from the latest `main`.
2. Keep commits focused and descriptive.
3. Open a pull request instead of pushing directly to `main`.
4. Request review from at least one teammate.
5. Merge only after the relevant smoke tests and documentation checks pass.

See [CONTRIBUTING.md](CONTRIBUTING.md) for review responsibilities and the pre-merge checklist.

## Roadmap

- [x] Initialize the repository and project documentation
- [x] Publish and verify the GitHub Pages landing page
- [ ] Complete Fashion-MNIST EDA and freeze the shared split
- [ ] Implement the Dataset/DataLoader and train-validation-test pipeline
- [ ] Train reproducible Linear and MLP baselines
- [ ] Complete the Assignment 1 draft milestone
- [ ] Implement CNN, LSTM/GRU, and Transformer models
- [ ] Run the full controlled comparison and error analysis
- [ ] Publish the Assignment 1 report, slides, video, and checkpoints
- [x] Publish the TrashCan-Material Assignment 2 proposal and EDA summary
- [ ] Obtain instructor approval before main Assignment 2 experiments

## Team

| Member | Student ID | Primary responsibility | GitHub |
|---|---|---|---|
| Nguyễn Hạo Thiên (A) | 2453194 | Data, EDA, preprocessing; Linear and CNN | [MrzThien1105](https://github.com/MrzThien1105) |
| Nguyễn Anh Khoa (B) | 2452539 | Trainer, evaluation, metrics, timing; MLP and LSTM/GRU | [TCL03-HCMUT](https://github.com/TCL03-HCMUT) |
| Tạ Tuấn Khải (C) | 2452515 | Config, reproducibility, integration/tests; Transformer and report/Pages integration | [TuanKhai1210](https://github.com/TuanKhai1210) |

Review rotation: Khoa reviews Thiên, Khải reviews Khoa, and Thiên reviews Khải. Each member writes and verifies the methodology, results, and analysis for their own work; report integration is not sole authorship.

## AI usage and research integrity

AI-assisted work is disclosed in [`AI_USAGE.md`](AI_USAGE.md). Every AI-generated suggestion must be reviewed, edited when necessary, and verified through source code, real experiment runs, official documentation, or scholarly sources.

The project does not report fabricated data, results, citations, or experiments that were not actually run.

## Academic context

This repository is developed as part of **CO3133 - Deep Learning and Its Applications**, Semester 261, at the Faculty of Computer Science and Engineering, Ho Chi Minh City University of Technology (VNU-HCM).

- Instructor: Lê Thành Sách
- Team size: 3 students
- Handbook baseline: revision 14 September 2026; see the [registration and submission update](docs/handbook-v2-update.md). Registration uses the official workbook with HCMUT email accounts. Final PDF reports are submitted by the designated representative on LMS, named `<GroupName>_A1_Report.pdf`, `<GroupName>_A2_Report.pdf`, or `<GroupName>_A3_Report.pdf`, matching the registered Group Name exactly.
- Project website: [Deep Learning Benchmark Suite](https://tuankhai1210.github.io/Deep-Learning-Benchmark-Suite/)

Course provenance is retained for transparency, while the repository is structured as a maintainable and reproducible machine-learning portfolio project.
