---
layout: default
title: "Assignment 3 AI Usage Disclosure"
---
# Assignment 3 — AI Usage Disclosure

## Scope

OpenAI Codex assisted with A3 planning, the ABO base pipeline, the fusion suite, test coverage, and documentation. A local CPU pilot on 300 ABO pairs verified the fusion workflow. The team will report final benchmark results from the reviewed product-group split.

## Review and verification

- AI-assisted planning suggestions must be reviewed by the assigned team member and a peer reviewer.
- Dataset provenance, citations, implementation choices, and quantitative results will be verified against independent sources and repository artifacts.
- Final report and presentation text will be reviewed by the full team.

## Use areas

- Assignment-requirement reconciliation.
- Dataset and research-design brainstorming.
- Documentation and website organization.
- Implementation and tests for the A3 CLI, review and split workflow, five-model benchmark, analysis and notebooks.

## Responsibility

Final academic responsibility remains with Group Tiki-taka. No Assignment 3 result or claim is represented as measured until it has a reproducible artifact. The complete project log is available in [AI_USAGE.md](../AI_USAGE.md).
