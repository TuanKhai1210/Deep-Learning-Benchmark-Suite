# A3 ABO · Chia train cho nhiều người

Dùng chung một bản **A3_ABO_team.zip**, một manifest đã chốt, hai tệp **image.npz** và **title.npz**, cùng **configs/a3/head.py**. Notebook 02 tạo file **benchmark_lock.json** để mỗi người kiểm đúng các đầu vào trước khi train. Có thể dùng cùng thư mục Drive thật hoặc sao chép nguyên thư mục **cohorts/abo-v1** (kể cả file lock) sang từng máy.

## Khi Colab báo thiếu freeze.json hoặc freeze-data thất bại

Ô **Chốt manifest** báo số dòng trống và ID đầu tiên cần xem lại. `REVIEWER` chỉ lưu tên người duyệt. Nếu chỉnh bảng trong Google Sheets, xuất lại CSV rồi cập nhật đúng file **reviews/abo-v1/decisions.csv** mà Colab đọc. CLI cũng hiện lỗi cụ thể khi file thay đổi, quyết định sai hoặc split không hợp lệ.

Mở Notebook 01 Prepare trong cùng WORK. Nếu đã có **reviews/abo-v1/decisions.csv**, dùng lại bảng audit đó. Hoàn thành cột decision và lưu CSV, điền **REVIEWER** rồi chạy ô **Chốt manifest**. Ô này tạo **cohorts/abo-v1/freeze.json** và **manifest.csv**. Sau đó đặt **ENCODE = True** và chạy ô tạo cache. Quay lại Notebook 02 và chọn **lock**.

Nếu một thành viên đã chuẩn bị dữ liệu ở workspace khác, sửa **WORK** trong ô Setup hoặc chép nguyên thư mục **cohorts/abo-v1** đã chốt, gồm manifest, receipt, hai cache và file lock nếu đã tạo. Nếu Colab đã có mã nguồn giải nén trực tiếp trong WORK, ô Setup có thể dùng thư mục đó khi thiếu ZIP.

## Bản cập nhật 21/11

Bản này nhận **keep** ở cặp hai ID để giữ cả hai mẫu mà không thêm liên kết hay buộc tách nhóm. Dùng **merge** để nối nhóm và **separate** để buộc hai nhóm khác nhau. Thay **A3_ABO_team.zip** trong WORK bằng bản này và mở lại Notebook 01. Nếu **A3_REPO** đang trỏ đến mã nguồn giải nén cũ, trỏ nó đến bản giải nén mới. Chạy lại Setup để nạp nguồn mới. Dùng lại ảnh, audit và CSV trên Drive.

## Cách chạy

1. **Prepare**. Dùng Notebook 01 để duyệt và chốt dữ liệu, rồi tạo hai cache. Nếu nhóm đã hoàn tất bước này với bản trước, tiếp tục dùng đúng các tệp đã chốt.
2. **Lock**. Một người mở Notebook 02, đặt **MODE = "lock"** rồi chạy notebook. Bàn giao bản ZIP này cùng cohort đã khóa. Trên Colab, thay bản ZIP trước trong thư mục làm việc bằng bản này, với cùng tên **A3_ABO_team.zip**. Mở Notebook 02 mới từ ZIP.
3. **Batch**. Mỗi người đặt **MODE = "batch"** và một **BATCH_ID** riêng rồi chạy một lần. Ví dụ:

   ```python
   BATCH_ID = "thien-01"
   MODELS = ["image-only"]
   SEEDS = [67, 69]
   PAIRS = []
   ```

   Ví dụ này chạy hai lượt. Thêm model vào MODELS để chạy mỗi model trên mọi seed đã chọn. Hoặc đặt `PAIRS = [("image-only", 67), ("concat", 69)]` để chỉ chạy hai cặp đó. Không có số lượt cố định cho từng thành viên. Nhóm chỉ cần phân đủ 15 cặp và tránh trùng. Nếu bị ngắt, chạy lại cùng BATCH_ID và danh sách cặp để tiếp tục từ lượt chưa hoàn thành.

4. **Collect**. Nếu mỗi người dùng máy hoặc Drive riêng, chép nguyên các thư mục batch về **WORK/batches** của người điều phối. Trong Notebook 02 đặt **MODE = "collect"**, điền **BATCH_IDS** và dùng một **A3_RUN_ID** cho suite chung. Nếu còn thiếu hoặc trùng cặp, notebook in tên các lượt cần xử lý.
5. **Test và Analysis**. Sau khi kiểm validation, chạy Notebook 03 rồi Notebook 04 với cùng **A3_RUN_ID**. Bảng điểm giữ batch, thiết bị và thời gian từng lượt để đối chiếu.

Local dùng checkout hoặc ZIP giải nén, cài Torch/Torchvision phù hợp rồi chạy `python -m pip install -e ".[a3,notebooks]"`. Đặt **A3_WORK** và **A3_REPO** nếu không dùng đường dẫn mặc định. Colab mặc định dùng **MyDrive/A3_ABO**, vì vậy nếu mỗi tài khoản thấy một thư mục khác nhau, hãy sửa **WORK** trong ô Setup để trỏ tới dữ liệu dùng chung hoặc bản sao đã khóa.

Notebook **02** cũng có chế độ **team** để một máy chạy cả suite. [Nguồn và giấy phép ABO](https://amazon-berkeley-objects.s3.us-east-1.amazonaws.com/index.html)
